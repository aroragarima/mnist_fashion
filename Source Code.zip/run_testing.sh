 python3 train.py -lr 0.01 -s 128 -opt 1 --save_dir saved_models/ -aug 1 -test
